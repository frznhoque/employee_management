package com.project.employee;

public class NoticeDA {

}
