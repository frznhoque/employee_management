package com.project.employee;

//import java.sql.Date;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
//import jakarta.persistence.JoinColumn;
//import jakarta.persistence.ManyToOne;

@Entity
public class Attendance {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	int attendanceId;
//	@ManyToOne
//    @JoinColumn(name = "employee_id")
	int employeeId;
	String month;
	String year;
	
	String a01;
	String a02;
	String a03;
	String a04;
	String a05;
	String a06;
	String a07;
	String a08;
	String a09;
	String a10;
	String a11;
	String a12;
	String a13;
	String a14;
	String a15;
	String a16;
	String a17;
	String a18;
	String a19;
	String a20;
	String a21;
	String a22;
	String a23;
	String a24;
	String a25;
	String a26;
	String a27;
	String a28;
	String a29;
	String a30;
	String a31;

	public Attendance() {
		super();
	}

	public Attendance(int attendanceId, int employeeId, String month, String year, String a01, String a02, String a03,
			String a04, String a05, String a06, String a07, String a08, String a09, String a10, String a11, String a12,
			String a13, String a14, String a15, String a16, String a17, String a18, String a19, String a20, String a21,
			String a22, String a23, String a24, String a25, String a26, String a27, String a28, String a29, String a30,
			String a31) {
		super();
		this.attendanceId = attendanceId;
		this.employeeId = employeeId;
		this.month = month;
		this.year = year;
		this.a01 = a01;
		this.a02 = a02;
		this.a03 = a03;
		this.a04 = a04;
		this.a05 = a05;
		this.a06 = a06;
		this.a07 = a07;
		this.a08 = a08;
		this.a09 = a09;
		this.a10 = a10;
		this.a11 = a11;
		this.a12 = a12;
		this.a13 = a13;
		this.a14 = a14;
		this.a15 = a15;
		this.a16 = a16;
		this.a17 = a17;
		this.a18 = a18;
		this.a19 = a19;
		this.a20 = a20;
		this.a21 = a21;
		this.a22 = a22;
		this.a23 = a23;
		this.a24 = a24;
		this.a25 = a25;
		this.a26 = a26;
		this.a27 = a27;
		this.a28 = a28;
		this.a29 = a29;
		this.a30 = a30;
		this.a31 = a31;
	}

	public int getAttendanceId() {
		return attendanceId;
	}

	public void setAttendanceId(int attendanceId) {
		this.attendanceId = attendanceId;
	}

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getA01() {
		return a01;
	}

	public void setA01(String a01) {
		this.a01 = a01;
	}

	public String getA02() {
		return a02;
	}

	public void setA02(String a02) {
		this.a02 = a02;
	}

	public String getA03() {
		return a03;
	}

	public void setA03(String a03) {
		this.a03 = a03;
	}

	public String getA04() {
		return a04;
	}

	public void setA04(String a04) {
		this.a04 = a04;
	}

	public String getA05() {
		return a05;
	}

	public void setA05(String a05) {
		this.a05 = a05;
	}

	public String getA06() {
		return a06;
	}

	public void setA06(String a06) {
		this.a06 = a06;
	}

	public String getA07() {
		return a07;
	}

	public void setA07(String a07) {
		this.a07 = a07;
	}

	public String getA08() {
		return a08;
	}

	public void setA08(String a08) {
		this.a08 = a08;
	}

	public String getA09() {
		return a09;
	}

	public void setA09(String a09) {
		this.a09 = a09;
	}

	public String getA10() {
		return a10;
	}

	public void setA10(String a10) {
		this.a10 = a10;
	}

	public String getA11() {
		return a11;
	}

	public void setA11(String a11) {
		this.a11 = a11;
	}

	public String getA12() {
		return a12;
	}

	public void setA12(String a12) {
		this.a12 = a12;
	}

	public String getA13() {
		return a13;
	}

	public void setA13(String a13) {
		this.a13 = a13;
	}

	public String getA14() {
		return a14;
	}

	public void setA14(String a14) {
		this.a14 = a14;
	}

	public String getA15() {
		return a15;
	}

	public void setA15(String a15) {
		this.a15 = a15;
	}

	public String getA16() {
		return a16;
	}

	public void setA16(String a16) {
		this.a16 = a16;
	}

	public String getA17() {
		return a17;
	}

	public void setA17(String a17) {
		this.a17 = a17;
	}

	public String getA18() {
		return a18;
	}

	public void setA18(String a18) {
		this.a18 = a18;
	}

	public String getA19() {
		return a19;
	}

	public void setA19(String a19) {
		this.a19 = a19;
	}

	public String getA20() {
		return a20;
	}

	public void setA20(String a20) {
		this.a20 = a20;
	}

	public String getA21() {
		return a21;
	}

	public void setA21(String a21) {
		this.a21 = a21;
	}

	public String getA22() {
		return a22;
	}

	public void setA22(String a22) {
		this.a22 = a22;
	}

	public String getA23() {
		return a23;
	}

	public void setA23(String a23) {
		this.a23 = a23;
	}

	public String getA24() {
		return a24;
	}

	public void setA24(String a24) {
		this.a24 = a24;
	}

	public String getA25() {
		return a25;
	}

	public void setA25(String a25) {
		this.a25 = a25;
	}

	public String getA26() {
		return a26;
	}

	public void setA26(String a26) {
		this.a26 = a26;
	}

	public String getA27() {
		return a27;
	}

	public void setA27(String a27) {
		this.a27 = a27;
	}

	public String getA28() {
		return a28;
	}

	public void setA28(String a28) {
		this.a28 = a28;
	}

	public String getA29() {
		return a29;
	}

	public void setA29(String a29) {
		this.a29 = a29;
	}

	public String getA30() {
		return a30;
	}

	public void setA30(String a30) {
		this.a30 = a30;
	}

	public String getA31() {
		return a31;
	}

	public void setA31(String a31) {
		this.a31 = a31;
	}

	@Override
	public String toString() {
		return "Attendance [attendanceId=" + attendanceId + ", employeeId=" + employeeId + ", month=" + month
				+ ", year=" + year + ", a01=" + a01 + ", a02=" + a02 + ", a03=" + a03 + ", a04=" + a04 + ", a05=" + a05
				+ ", a06=" + a06 + ", a07=" + a07 + ", a08=" + a08 + ", a09=" + a09 + ", a10=" + a10 + ", a11=" + a11
				+ ", a12=" + a12 + ", a13=" + a13 + ", a14=" + a14 + ", a15=" + a15 + ", a16=" + a16 + ", a17=" + a17
				+ ", a18=" + a18 + ", a19=" + a19 + ", a20=" + a20 + ", a21=" + a21 + ", a22=" + a22 + ", a23=" + a23
				+ ", a24=" + a24 + ", a25=" + a25 + ", a26=" + a26 + ", a27=" + a27 + ", a28=" + a28 + ", a29=" + a29
				+ ", a30=" + a30 + ", a31=" + a31 + ", getAttendanceId()=" + getAttendanceId() + ", getEmployeeId()="
				+ getEmployeeId() + ", getMonth()=" + getMonth() + ", getYear()=" + getYear() + ", getA01()=" + getA01()
				+ ", getA02()=" + getA02() + ", getA03()=" + getA03() + ", getA04()=" + getA04() + ", getA05()="
				+ getA05() + ", getA06()=" + getA06() + ", getA07()=" + getA07() + ", getA08()=" + getA08()
				+ ", getA09()=" + getA09() + ", getA10()=" + getA10() + ", getA11()=" + getA11() + ", getA12()="
				+ getA12() + ", getA13()=" + getA13() + ", getA14()=" + getA14() + ", getA15()=" + getA15()
				+ ", getA16()=" + getA16() + ", getA17()=" + getA17() + ", getA18()=" + getA18() + ", getA19()="
				+ getA19() + ", getA20()=" + getA20() + ", getA21()=" + getA21() + ", getA22()=" + getA22()
				+ ", getA23()=" + getA23() + ", getA24()=" + getA24() + ", getA25()=" + getA25() + ", getA26()="
				+ getA26() + ", getA27()=" + getA27() + ", getA28()=" + getA28() + ", getA29()=" + getA29()
				+ ", getA30()=" + getA30() + ", getA31()=" + getA31() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	
}
